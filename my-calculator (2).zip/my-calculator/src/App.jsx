import { useState, useCallback, useEffect } from "react";

const isOperator = (val) => ["÷", "×", "−", "+"].includes(val);

const buttons = [
  ["AC", "⌫", "%", "÷"],
  ["7", "8", "9", "×"],
  ["4", "5", "6", "−"],
  ["1", "2", "3", "+"],
  ["0", ".", "="],
];

export default function Calculator() {
  const [display, setDisplay] = useState("0");
  const [expression, setExpression] = useState("");
  const [prevValue, setPrevValue] = useState(null);
  const [operator, setOperator] = useState(null);
  const [waitingForOperand, setWaitingForOperand] = useState(false);
  const [justCalculated, setJustCalculated] = useState(false);
  const [history, setHistory] = useState([]);
  const [showHistory, setShowHistory] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [shake, setShake] = useState(false);
  const [pressedBtn, setPressedBtn] = useState(null);

  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth <= 600);
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);

  useEffect(() => {
    const style = document.createElement("style");
    style.innerHTML = `
      @import url('https://fonts.googleapis.com/css2?family=SF+Pro+Display:wght@200;300;400&display=swap');
      * { -webkit-font-smoothing: antialiased; }
      @keyframes shake {
        0%,100% { transform: translateX(0); }
        20% { transform: translateX(-10px); }
        40% { transform: translateX(10px); }
        60% { transform: translateX(-6px); }
        80% { transform: translateX(6px); }
      }
      @keyframes popIn {
        0% { transform: scale(0.92); opacity: 0.6; }
        60% { transform: scale(1.04); }
        100% { transform: scale(1); opacity: 1; }
      }
      @keyframes fadeSlideUp {
        from { opacity: 0; transform: translateY(16px); }
        to { opacity: 1; transform: translateY(0); }
      }
      .shake { animation: shake 0.4s ease; }
      .pop { animation: popIn 0.18s ease forwards; }
      .slide-up { animation: fadeSlideUp 0.3s ease forwards; }
      body { margin: 0; background: #000; }
    `;
    document.head.appendChild(style);
    return () => document.head.removeChild(style);
  }, []);

  const triggerShake = () => {
    setShake(true);
    setTimeout(() => setShake(false), 400);
  };

  const calculate = useCallback((a, b, op) => {
    switch (op) {
      case "+": return a + b;
      case "−": return a - b;
      case "×": return a * b;
      case "÷": return b !== 0 ? a / b : "Error";
      default: return b;
    }
  }, []);

  const formatNum = (num) => {
    if (num === "Error") return "Error";
    const n = parseFloat(num);
    if (isNaN(n)) return "Error";
    const str = n.toString();
    if (str.length > 12) return parseFloat(n.toPrecision(9)).toString();
    return str;
  };

  const handleButton = (val) => {
    setPressedBtn(val);
    setTimeout(() => setPressedBtn(null), 150);

    if (val === "AC") {
      setDisplay("0"); setExpression("");
      setPrevValue(null); setOperator(null);
      setWaitingForOperand(false); setJustCalculated(false);
      return;
    }
    if (val === "⌫") {
      if (display === "Error") { setDisplay("0"); return; }
      setDisplay(d => d.length <= 1 || (d.length === 2 && d.startsWith("-")) ? "0" : d.slice(0, -1));
      return;
    }
    if (val === "%") { setDisplay((p) => (parseFloat(p) / 100).toString()); return; }

    if (isOperator(val)) {
      const cur = parseFloat(display);
      if (prevValue !== null && !waitingForOperand) {
        const res = calculate(prevValue, cur, operator);
        const fmt = formatNum(res);
        if (fmt === "Error") { triggerShake(); setDisplay("Error"); return; }
        setDisplay(fmt);
        setPrevValue(typeof res === "number" ? res : null);
        setExpression(`${fmt} ${val}`);
      } else {
        // after = or fresh start, use current display as prevValue
        setPrevValue(cur);
        setExpression(`${display} ${val}`);
      }
      setOperator(val); setWaitingForOperand(true); setJustCalculated(false);
      return;
    }

    if (val === "=") {
      if (operator && prevValue !== null) {
        const cur = parseFloat(display);
        const res = calculate(prevValue, cur, operator);
        const fmt = formatNum(res);
        if (fmt === "Error") { triggerShake(); setDisplay("Error"); return; }
        const entry = `${prevValue} ${operator} ${display} = ${fmt}`;
        setHistory(h => [entry, ...h].slice(0, 30));
        setExpression(`${prevValue} ${operator} ${display} =`);
        setDisplay(fmt);
        setPrevValue(null); setOperator(null);
        setWaitingForOperand(false); setJustCalculated(true);
      }
      return;
    }

    if (val === ".") {
      if (waitingForOperand) { setDisplay("0."); setWaitingForOperand(false); return; }
      if (!display.includes(".")) setDisplay(d => d + ".");
      return;
    }

    if (waitingForOperand || justCalculated) {
      setDisplay(val); setWaitingForOperand(false); setJustCalculated(false);
    } else {
      setDisplay(d => d === "0" ? val : d.length < 12 ? d + val : d);
    }
  };

  // iPhone-style button colors
  const getBtnStyle = (val) => {
    const isEq = val === "=";
    const isOp = isOperator(val);
    const isTop = ["AC", "⌫", "%"].includes(val);
    const isBack = val === "⌫";
    const pressed = pressedBtn === val;

    if (isEq) return {
      bg: pressed ? "#e6c740" : "#FFD60A",
      color: "#000",
      shadow: "0 2px 12px rgba(255,214,10,0.45)",
      fontSize: isMobile ? 28 : 26,
      fontWeight: "300",
    };
    if (isOp) return {
      bg: pressed ? "#c0782a" : "#FF9F0A",
      color: "#fff",
      shadow: "0 2px 10px rgba(255,159,10,0.35)",
      fontSize: isMobile ? 28 : 26,
      fontWeight: "300",
    };
    if (isBack) return {
      bg: pressed ? "#6e6e73" : "#3A3A3C",
      color: "#FF6B6B",
      shadow: "none",
      fontSize: isMobile ? 20 : 18,
      fontWeight: "400",
    };
    if (isTop) return {
      bg: pressed ? "#6e6e73" : "#3A3A3C",
      color: "#fff",
      shadow: "none",
      fontSize: isMobile ? 17 : 16,
      fontWeight: "400",
    };
    return {
      bg: pressed ? "#8e8e93" : "#1C1C1E",
      color: "#fff",
      shadow: "none",
      fontSize: isMobile ? 26 : 24,
      fontWeight: "300",
    };
  };

  const btnSize = isMobile ? 76 : 72;
  const displayFS = isMobile
    ? (display.length > 9 ? 38 : display.length > 6 ? 52 : 70)
    : (display.length > 9 ? 34 : display.length > 6 ? 46 : 62);

  return (
    <div style={{
      minHeight: "100vh", minHeight: "100dvh",
      background: "#000",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: isMobile ? "flex-end" : "center",
      fontFamily: "-apple-system, 'SF Pro Display', 'Helvetica Neue', sans-serif",
      overflow: "hidden",
      position: "relative",
    }}>

      {/* History overlay */}
      {showHistory && (
        <div className="slide-up" style={{
          position: "fixed", inset: 0,
          background: "rgba(0,0,0,0.92)",
          backdropFilter: "blur(30px)",
          zIndex: 100,
          display: "flex", flexDirection: "column",
          padding: isMobile ? "60px 20px 40px" : "40px",
          overflowY: "auto",
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
            <span style={{ color: "#fff", fontSize: 22, fontWeight: 600 }}>History</span>
            <div style={{ display: "flex", gap: 12 }}>
              <button onClick={() => setHistory([])} style={{
                background: "rgba(255,255,255,0.1)", border: "none", borderRadius: 20,
                padding: "6px 16px", color: "#FF6B6B", fontSize: 13, cursor: "pointer",
              }}>Clear</button>
              <button onClick={() => setShowHistory(false)} style={{
                background: "rgba(255,255,255,0.1)", border: "none", borderRadius: 20,
                padding: "6px 16px", color: "#FFD60A", fontSize: 13, cursor: "pointer",
              }}>Done</button>
            </div>
          </div>
          {history.length === 0
            ? <div style={{ color: "rgba(255,255,255,0.3)", textAlign: "center", marginTop: 40, fontSize: 15 }}>No history yet</div>
            : history.map((h, i) => (
              <div key={i} style={{
                padding: "14px 0",
                borderBottom: "1px solid rgba(255,255,255,0.07)",
                color: i === 0 ? "#FFD60A" : "rgba(255,255,255,0.55)",
                fontSize: isMobile ? 16 : 17,
                lineHeight: 1.5,
              }}>{h}</div>
            ))
          }
        </div>
      )}

      {/* Main calculator */}
      <div style={{
        width: isMobile ? "100%" : 360,
        background: "#000",
        borderRadius: isMobile ? "40px 40px 0 0" : 44,
        border: isMobile ? "none" : "1px solid rgba(255,255,255,0.08)",
        padding: isMobile ? "0 16px 28px" : "32px 24px 32px",
        boxSizing: "border-box",
        boxShadow: isMobile ? "none" : "0 40px 120px rgba(0,0,0,0.9)",
      }}>

        {/* TAJ UDDIN branding */}
        <div style={{
          textAlign: "center",
          paddingTop: isMobile ? 20 : 0,
          marginBottom: 8,
        }}>
          <div style={{
            fontSize: 11,
            letterSpacing: "0.3em",
            textTransform: "uppercase",
            color: "rgba(255,214,10,0.6)",
            fontWeight: 500,
          }}>TAJ UDDIN</div>
          <div style={{
            fontSize: 8,
            letterSpacing: "0.2em",
            color: "rgba(255,255,255,0.2)",
            marginTop: 2,
          }}>DEVELOPED BY</div>
        </div>

        {/* History button */}
        <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 4 }}>
          <button onClick={() => setShowHistory(true)} style={{
            background: "rgba(255,255,255,0.07)",
            border: "1px solid rgba(255,255,255,0.1)",
            borderRadius: 20, padding: "5px 14px",
            color: "rgba(255,255,255,0.5)",
            fontSize: 11, cursor: "pointer",
            WebkitTapHighlightColor: "transparent",
          }}>History</button>
        </div>

        {/* Expression */}
        <div style={{
          textAlign: "right",
          color: "rgba(255,255,255,0.35)",
          fontSize: 16,
          minHeight: 22,
          marginBottom: 2,
          paddingRight: 4,
          overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
          fontWeight: 300,
        }}>{expression || "\u00A0"}</div>

        {/* Display */}
        <div
          className={shake ? "shake" : ""}
          style={{
            textAlign: "right",
            fontSize: displayFS,
            fontWeight: 200,
            color: display === "Error" ? "#FF6B6B" : "#fff",
            letterSpacing: "-0.03em",
            lineHeight: 1.05,
            minHeight: isMobile ? 80 : 76,
            display: "flex", alignItems: "flex-end", justifyContent: "flex-end",
            paddingRight: 4,
            marginBottom: 24,
            overflow: "hidden",
            transition: "color 0.2s, font-size 0.1s",
          }}>{display}</div>

        {/* Button grid */}
        <div style={{ display: "flex", flexDirection: "column", gap: isMobile ? 12 : 10 }}>
          {buttons.map((row, ri) => (
            <div key={ri} style={{
              display: "grid",
              gridTemplateColumns: row.length === 3 ? "2fr 1fr 1fr" : "repeat(4, 1fr)",
              gap: isMobile ? 12 : 10,
            }}>
              {row.map((val) => {
                const s = getBtnStyle(val);
                return (
                  <button
                    key={val}
                    style={{
                      height: btnSize,
                      borderRadius: btnSize / 2,
                      background: s.bg,
                      color: s.color,
                      border: "none",
                      cursor: "pointer",
                      fontSize: s.fontSize,
                      fontWeight: s.fontWeight,
                      fontFamily: "-apple-system, 'SF Pro Display', 'Helvetica Neue', sans-serif",
                      boxShadow: s.shadow,
                      outline: "none",
                      transition: "background 0.1s, transform 0.08s",
                      WebkitTapHighlightColor: "transparent",
                      touchAction: "manipulation",
                      transform: pressedBtn === val ? "scale(0.90)" : "scale(1)",
                      // Green glow on tap for number buttons
                      ...(pressedBtn === val && !isOperator(val) && val !== "=" && !["AC","⌫","%"].includes(val) ? {
                        boxShadow: "0 0 0 3px rgba(52,199,89,0.55), 0 0 18px rgba(52,199,89,0.3)",
                        color: "#34C759",
                      } : {}),
                    }}
                    onTouchStart={(e) => { e.preventDefault(); setPressedBtn(val); }}
                    onTouchEnd={(e) => { e.preventDefault(); handleButton(val); setTimeout(() => setPressedBtn(null), 150); }}
                    onMouseDown={() => setPressedBtn(val)}
                    onMouseUp={() => { handleButton(val); setPressedBtn(null); }}
                    onMouseLeave={() => setPressedBtn(null)}
                  >{val}</button>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
